import sys,json,io
from docx import Document
from docx.shared import Cm,Pt,RGBColor
qs=json.load(sys.stdin)
doc=Document();section=doc.sections[0];section.top_margin=Cm(2);section.bottom_margin=Cm(2)
doc.add_heading('NGÂN HÀNG CÂU HỎI VSAT – TOÁN',0)
doc.add_paragraph('Bản xuất từ trang quản lý website VSAT 2027.')
for i,q in enumerate(qs,1):
 doc.add_heading(f'Câu {i} – {q.get("type","")} – {q.get("points",6)} điểm',level=2)
 doc.add_paragraph(q.get('prompt',''))
 if q.get('options'):doc.add_paragraph('Lựa chọn: '+q['options'].replace('|','  |  '))
 doc.add_paragraph('Đáp án: '+q.get('answer',''))
 doc.add_paragraph('Trạng thái: '+('Đang dùng' if q.get('active') else 'Ẩn'))
b=io.BytesIO();doc.save(b);sys.stdout.buffer.write(b.getvalue())
