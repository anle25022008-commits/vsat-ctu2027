# WEBSITE THI THỬ VSAT 2027 — BẢN MẪU CHẠY ĐƯỢC

Ứng dụng Node.js dùng thư viện chuẩn, không cần `npm install`. Thiết kế theo bố cục ảnh tham khảo: thẻ **Thông tin thí sinh** căn giữa, số báo danh CTU, môn Toán, điểm thi màu đỏ, trang làm bài và quản trị tông xanh.

## Chạy thử

Yêu cầu Node.js 18+ và Python 3 có cài `python-docx` (chỉ cần cho chức năng xuất Word).

```bash
cd VSAT_WEB_THI_THU_2027
node server.js
```

Mở http://localhost:3000

**Tài khoản quản lý mặc định theo yêu cầu:** `123456` / `123456`. Đây là thông tin **không an toàn để triển khai công khai**. Trước khi đưa lên Internet, phải đổi mật khẩu bằng biến môi trường `ADMIN_USER` và `ADMIN_PASS` (ít nhất 12 ký tự), và đặt `SESSION_SECRET` dài ngẫu nhiên.

Ví dụ Linux/macOS:

```bash
ADMIN_USER=quanly ADMIN_PASS='MATKHAU_MOI_RAT_DAI' SESSION_SECRET='CHUOI_NGAU_NHIEN_DAI_32_KY_TU' node server.js
```

## Đã có

- Đăng ký thi thử (họ tên, ngày sinh, số điện thoại, ca thi), quản lý xem và duyệt.
- Khi duyệt, hệ thống tạo **CTU + 5 chữ số** và **mật khẩu ngẫu nhiên 5 chữ số**; mật khẩu chỉ hiển thị **một lần** khi cấp và được lưu dưới dạng băm.
- Đăng nhập thí sinh, trang thông tin thí sinh theo ảnh mẫu, làm bài theo câu hỏi đang kích hoạt, nộp bài và xem điểm.
- Quản trị: đăng ký, duyệt, danh sách thí sinh, điểm, xem lại bài làm, tải bài làm JSON, in/lưu PDF bằng trình duyệt, xuất danh sách CSV.
- Ngân hàng câu hỏi: thêm, sửa, bật/tắt câu hỏi, xuất toàn bộ ngân hàng Word (.docx).
- Quản lý thi thử không giới hạn, kết quả luyện tập không trộn với điểm thí sinh.

## Giới hạn quan trọng trước khi sử dụng thật

- **Chưa có bộ câu hỏi chuẩn được xác minh và nhập sẵn.** Tài liệu PDF trong gói bàn giao không tự chuyển thành câu hỏi vì cần kiểm tra nội dung, hình vẽ và đáp án.
- Đồng hồ 90 phút hiện là **bộ đếm phía trình duyệt**, chưa phải kiểm soát thời gian tin cậy trên máy chủ. Chưa có giờ mở/đóng thi, tự lưu bài, chống nộp trùng, phân quyền nâng cao, rate limiting, phục hồi mật khẩu, ghi log kiểm toán, sao lưu tự động.
- Trắc nghiệm chấm tự động theo đáp án A/B/C/D; Đúng/Sai và Ghép cột nhập đáp án bằng `|`, chia đều điểm theo từng ý; Trả lời ngắn so khớp chuỗi. **Cần kiểm tra lại thang điểm chính thức trước khi sử dụng.**
- Lưu trữ JSON thích hợp để chạy thử trên **một máy**; chưa phù hợp cho kỳ thi có nhiều thí sinh đồng thời. Khi triển khai thực tế cần cơ sở dữ liệu giao dịch (PostgreSQL), HTTPS, sao lưu, bảo vệ dữ liệu cá nhân, giới hạn đăng nhập, CSRF cho toàn bộ thao tác, quản lý phiên bền vững và kiểm thử tải.
- Chưa kết nối website cũ hoặc dữ liệu thí sinh mới nhất. Không tự chuyển dữ liệu nhạy cảm từ gói bàn giao vào website mới.

## Bảo mật

Không đăng thư mục `data/` lên kho mã nguồn công khai. Mật khẩu 5 số theo yêu cầu có độ mạnh thấp; nên bổ sung khóa tạm thời khi nhập sai, mã hóa HTTPS và chính sách cấp lại mật khẩu. Tài khoản quản lý mặc định phải được đổi trước khi công bố URL.

## Cập nhật giao diện đăng nhập
Trang `/` và `/login` chỉ có hai ô tài khoản, mật khẩu và nút đăng nhập lớn. Cấu trúc đề gốc được trích vào `exam_config.json`; phần chấm điểm trong `server.js` **chưa áp dụng đúng quy tắc đúng/sai 1/2/3/6** và cần chỉnh trước khi mở thi chính thức. Các PDF trong gói bàn giao chưa được nhập tự động vì chưa xác minh đáp án.
